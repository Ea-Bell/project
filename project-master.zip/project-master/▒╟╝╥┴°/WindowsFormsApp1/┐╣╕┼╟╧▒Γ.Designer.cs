﻿namespace WindowsFormsApp1
{
    partial class 예매하기
    {
        /// <summary>
        /// 필수 디자이너 변수입니다.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 사용 중인 모든 리소스를 정리합니다.
        /// </summary>
        /// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 디자이너에서 생성한 코드

        /// <summary>
        /// 디자이너 지원에 필요한 메서드입니다. 
        /// 이 메서드의 내용을 코드 편집기로 수정하지 마세요.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(예매하기));
            this.극한직업 = new System.Windows.Forms.PictureBox();
            this.범죄도시 = new System.Windows.Forms.PictureBox();
            this.라라랜드 = new System.Windows.Forms.PictureBox();
            this.타짜 = new System.Windows.Forms.PictureBox();
            this.청년경찰 = new System.Windows.Forms.PictureBox();
            this.엑시트 = new System.Windows.Forms.PictureBox();
            this.극한btn = new System.Windows.Forms.Button();
            this.범죄btn = new System.Windows.Forms.Button();
            this.라라btn = new System.Windows.Forms.Button();
            this.타짜btn = new System.Windows.Forms.Button();
            this.청년btn = new System.Windows.Forms.Button();
            this.엑시btn = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.극한직업)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.범죄도시)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.라라랜드)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.타짜)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.청년경찰)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.엑시트)).BeginInit();
            this.SuspendLayout();
            // 
            // 극한직업
            // 
            this.극한직업.Image = ((System.Drawing.Image)(resources.GetObject("극한직업.Image")));
            this.극한직업.Location = new System.Drawing.Point(21, 21);
            this.극한직업.Name = "극한직업";
            this.극한직업.Size = new System.Drawing.Size(209, 274);
            this.극한직업.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.극한직업.TabIndex = 0;
            this.극한직업.TabStop = false;
            this.극한직업.Click += new System.EventHandler(this.극한직업_Click);
            // 
            // 범죄도시
            // 
            this.범죄도시.Image = ((System.Drawing.Image)(resources.GetObject("범죄도시.Image")));
            this.범죄도시.Location = new System.Drawing.Point(249, 21);
            this.범죄도시.Name = "범죄도시";
            this.범죄도시.Size = new System.Drawing.Size(209, 274);
            this.범죄도시.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.범죄도시.TabIndex = 1;
            this.범죄도시.TabStop = false;
            this.범죄도시.Click += new System.EventHandler(this.범죄도시_Click);
            // 
            // 라라랜드
            // 
            this.라라랜드.Image = ((System.Drawing.Image)(resources.GetObject("라라랜드.Image")));
            this.라라랜드.Location = new System.Drawing.Point(476, 21);
            this.라라랜드.Name = "라라랜드";
            this.라라랜드.Size = new System.Drawing.Size(209, 274);
            this.라라랜드.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.라라랜드.TabIndex = 2;
            this.라라랜드.TabStop = false;
            this.라라랜드.Click += new System.EventHandler(this.라라랜드_Click);
            // 
            // 타짜
            // 
            this.타짜.Image = ((System.Drawing.Image)(resources.GetObject("타짜.Image")));
            this.타짜.Location = new System.Drawing.Point(701, 21);
            this.타짜.Name = "타짜";
            this.타짜.Size = new System.Drawing.Size(209, 274);
            this.타짜.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.타짜.TabIndex = 3;
            this.타짜.TabStop = false;
            this.타짜.Click += new System.EventHandler(this.타짜_Click);
            // 
            // 청년경찰
            // 
            this.청년경찰.Image = ((System.Drawing.Image)(resources.GetObject("청년경찰.Image")));
            this.청년경찰.Location = new System.Drawing.Point(935, 28);
            this.청년경찰.Name = "청년경찰";
            this.청년경찰.Size = new System.Drawing.Size(209, 274);
            this.청년경찰.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.청년경찰.TabIndex = 4;
            this.청년경찰.TabStop = false;
            this.청년경찰.Click += new System.EventHandler(this.청년경찰_Click);
            // 
            // 엑시트
            // 
            this.엑시트.Image = ((System.Drawing.Image)(resources.GetObject("엑시트.Image")));
            this.엑시트.Location = new System.Drawing.Point(1150, 21);
            this.엑시트.Name = "엑시트";
            this.엑시트.Size = new System.Drawing.Size(209, 274);
            this.엑시트.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.엑시트.TabIndex = 5;
            this.엑시트.TabStop = false;
            this.엑시트.Click += new System.EventHandler(this.엑시트_Click);
            // 
            // 극한btn
            // 
            this.극한btn.BackColor = System.Drawing.Color.White;
            this.극한btn.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.극한btn.Font = new System.Drawing.Font("굴림", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.극한btn.ForeColor = System.Drawing.Color.Blue;
            this.극한btn.Location = new System.Drawing.Point(63, 320);
            this.극한btn.Name = "극한btn";
            this.극한btn.Size = new System.Drawing.Size(105, 31);
            this.극한btn.TabIndex = 6;
            this.극한btn.Text = "예매하기";
            this.극한btn.UseVisualStyleBackColor = false;
            this.극한btn.Click += new System.EventHandler(this.극한btn_Click);
            // 
            // 범죄btn
            // 
            this.범죄btn.BackColor = System.Drawing.Color.White;
            this.범죄btn.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.범죄btn.Font = new System.Drawing.Font("굴림", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.범죄btn.ForeColor = System.Drawing.Color.Blue;
            this.범죄btn.Location = new System.Drawing.Point(292, 320);
            this.범죄btn.Name = "범죄btn";
            this.범죄btn.Size = new System.Drawing.Size(105, 31);
            this.범죄btn.TabIndex = 7;
            this.범죄btn.Text = "예매하기";
            this.범죄btn.UseVisualStyleBackColor = false;
            this.범죄btn.Click += new System.EventHandler(this.범죄btn_Click);
            // 
            // 라라btn
            // 
            this.라라btn.BackColor = System.Drawing.Color.White;
            this.라라btn.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.라라btn.Font = new System.Drawing.Font("굴림", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.라라btn.ForeColor = System.Drawing.Color.Blue;
            this.라라btn.Location = new System.Drawing.Point(530, 320);
            this.라라btn.Name = "라라btn";
            this.라라btn.Size = new System.Drawing.Size(105, 31);
            this.라라btn.TabIndex = 8;
            this.라라btn.Text = "예매하기";
            this.라라btn.UseVisualStyleBackColor = false;
            this.라라btn.Click += new System.EventHandler(this.라라btn_Click);
            // 
            // 타짜btn
            // 
            this.타짜btn.BackColor = System.Drawing.Color.White;
            this.타짜btn.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.타짜btn.Font = new System.Drawing.Font("굴림", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.타짜btn.ForeColor = System.Drawing.Color.Blue;
            this.타짜btn.Location = new System.Drawing.Point(752, 320);
            this.타짜btn.Name = "타짜btn";
            this.타짜btn.Size = new System.Drawing.Size(105, 31);
            this.타짜btn.TabIndex = 9;
            this.타짜btn.Text = "예매하기";
            this.타짜btn.UseVisualStyleBackColor = false;
            this.타짜btn.Click += new System.EventHandler(this.타짜btn_Click);
            // 
            // 청년btn
            // 
            this.청년btn.BackColor = System.Drawing.Color.White;
            this.청년btn.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.청년btn.Font = new System.Drawing.Font("굴림", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.청년btn.ForeColor = System.Drawing.Color.Blue;
            this.청년btn.Location = new System.Drawing.Point(973, 320);
            this.청년btn.Name = "청년btn";
            this.청년btn.Size = new System.Drawing.Size(105, 31);
            this.청년btn.TabIndex = 10;
            this.청년btn.Text = "예매하기";
            this.청년btn.UseVisualStyleBackColor = false;
            this.청년btn.Click += new System.EventHandler(this.청년btn_Click);
            // 
            // 엑시btn
            // 
            this.엑시btn.BackColor = System.Drawing.Color.White;
            this.엑시btn.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.엑시btn.Font = new System.Drawing.Font("굴림", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.엑시btn.ForeColor = System.Drawing.Color.Blue;
            this.엑시btn.Location = new System.Drawing.Point(1206, 320);
            this.엑시btn.Name = "엑시btn";
            this.엑시btn.Size = new System.Drawing.Size(105, 31);
            this.엑시btn.TabIndex = 11;
            this.엑시btn.Text = "예매하기";
            this.엑시btn.UseVisualStyleBackColor = false;
            this.엑시btn.Click += new System.EventHandler(this.엑시btn_Click);
            // 
            // 예매하기
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(999, 413);
            this.Controls.Add(this.엑시btn);
            this.Controls.Add(this.청년btn);
            this.Controls.Add(this.타짜btn);
            this.Controls.Add(this.라라btn);
            this.Controls.Add(this.범죄btn);
            this.Controls.Add(this.극한btn);
            this.Controls.Add(this.엑시트);
            this.Controls.Add(this.청년경찰);
            this.Controls.Add(this.타짜);
            this.Controls.Add(this.라라랜드);
            this.Controls.Add(this.범죄도시);
            this.Controls.Add(this.극한직업);
            this.Name = "예매하기";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.극한직업)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.범죄도시)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.라라랜드)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.타짜)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.청년경찰)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.엑시트)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.PictureBox 극한직업;
        private System.Windows.Forms.PictureBox 범죄도시;
        private System.Windows.Forms.PictureBox 라라랜드;
        private System.Windows.Forms.PictureBox 타짜;
        private System.Windows.Forms.PictureBox 청년경찰;
        private System.Windows.Forms.PictureBox 엑시트;
        private System.Windows.Forms.Button 극한btn;
        private System.Windows.Forms.Button 범죄btn;
        private System.Windows.Forms.Button 라라btn;
        private System.Windows.Forms.Button 타짜btn;
        private System.Windows.Forms.Button 청년btn;
        private System.Windows.Forms.Button 엑시btn;
    }
}

